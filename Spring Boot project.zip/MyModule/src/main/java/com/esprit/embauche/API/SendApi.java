package com.esprit.embauche.API;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping(value = "/api/email")
public class SendApi {
	
	@Autowired
	private EmailApi e;
	
	@GetMapping(value = "/{to}/{sub}/{text}")
	@ResponseStatus(HttpStatus.OK)
	public ResponseEntity send(@PathVariable(value = "to") String to,@PathVariable(value = "sub") String sub,@PathVariable(value = "text") String text){
		e.sendSimpleMessage(to, sub, text);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}

}
