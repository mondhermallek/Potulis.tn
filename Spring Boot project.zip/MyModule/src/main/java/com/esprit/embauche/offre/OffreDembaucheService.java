package com.esprit.embauche.offre;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service
public class OffreDembaucheService {
	
	@Autowired
	private OffreDembaucheRepository o;
	
	//Ajouter une offre d'embauche;
	public OffreDembauche addOffre(OffreDembauche offre){return o.save(offre);}
	// Récupérer toutes les offres
	public  List<OffreDembauche> getOffers() {return o.findAll();}
	//Mettre A jour uns offre d'embauche
	public OffreDembauche updateOffre(int id,OffreDembauche newoffre)
	{
		if(o.findById(id).isPresent()) {
			OffreDembauche existing = o.findById(id).get();
			existing.setDate_d_publication(newoffre.getDate_d_publication());
			existing.setDate_d_expiration(newoffre.getDate_d_expiration());
			existing.setEntreprise(newoffre.getEntreprise());
			existing.setDescription(newoffre.getDescription());
			existing.setCompetances(newoffre.getCompetances());
			existing.setExigences(newoffre.getExigences());
			existing.setLieux(newoffre.getLieux());
			existing.setPoste(newoffre.getPoste());
			existing.setNbplace(newoffre.getNbplace());
			existing.setcandidats(newoffre.getcandidats());
			
			return o.save(existing);
		}
		else {
			return null;
		}
	}
	// Supprimer une offre d'embauche
	public String Deleteoffre(int id)
	{
		if(o.findById(id).isPresent()) {
			o.deleteById(id);
			return "Deleted";
		}
		else {
			return "NOT FOUND";
		}
	}
	// Cherché par id
	public OffreDembauche findoffre(int id) {
		if(o.findById(id).isPresent()) {
			OffreDembauche existing = o.findById(id).get();
			return existing;
		}
		else {
			return null;
		}
	}
	
	

}
