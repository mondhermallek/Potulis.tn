package com.esprit.embauche.offre;

import org.springframework.data.jpa.repository.JpaRepository;



public interface OffreDembaucheRepository extends JpaRepository<OffreDembauche, Integer> {

}
