package com.esprit.embauche.postule;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.esprit.embauche.offre.OffreDembauche;
import com.esprit.embauche.offre.OffreDembaucheRepository;
import com.esprit.embauche.offre.OffreDembaucheService;





@Service
public class PostuleService {
	@Autowired
	private PostuleRepository o;
	@Autowired 
	private OffreDembaucheRepository of;
	@Autowired 
	private OffreDembaucheService sof;
	
	
	
	    //Ajouter une offre d'embauche;
		public Postule addPostule(int id,Postule postule){
			of.findById(id).map(aux->{postule.setOffreid(aux);return o.save(postule);});
			return postule;
		}
		// Récupérer toutes les offres
		public  List<Postule> getPostules() {return o.findAll();}
		//Mettre A jour uns offre d'embauche
		public Postule updatepostule(Postule newpostule,int id_child)
		{
			if(o.findById(id_child).isPresent()) {
				
				Postule existing = o.findById(id_child).get();
				existing.setCandidat_name(newpostule.getCandidat_name());
				existing.setEmail(newpostule.getEmail());
				//existing.setOffreid(newpostule.getOffreid());
				existing.setPhone(newpostule.getPhone());
				o.save(existing);
				return existing;
			}
			else {
				return null;
			}
			
			
		}
		// Supprimer une offre d'embauche
		public String Deletepostule(int id)
		{
			if(o.findById(id).isPresent()) {
				o.deleteById(id);
				return "Deleted";
			}
			else {
				return "NOT FOUND";
			}
		}
		// Cherché par id
		public Postule findpostule(int id) {
			if(o.findById(id).isPresent()) {
				Postule existing = o.findById(id).get();
				return existing;
			}
			else {
				return null;
			}
		}

}
