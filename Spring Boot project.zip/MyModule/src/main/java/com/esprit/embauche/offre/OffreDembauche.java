package com.esprit.embauche.offre;

import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.esprit.embauche.postule.Postule;





@Entity
@Table(name = "offers")
public class OffreDembauche implements Serializable {
	private static final long serialVersionUID = 6;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private Date date_d_expiration;
	
	private Date date_d_publication;
	
	private String Entreprise,lieux,description,exigences,competances,poste;
	
	private int nbplace;
	
	//@JsonManagedReference
	@OneToMany(mappedBy="offreid",fetch=FetchType.EAGER)
    Set<Postule> candidats = new HashSet<Postule>();
	
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDate_d_expiration() {
		return date_d_expiration;
	}
	public void setDate_d_expiration(Date date_d_expiration) {
		this.date_d_expiration = date_d_expiration;
	}
	public Date getDate_d_publication() {
		return date_d_publication;
	}
	public void setDate_d_publication(Date date_d_publication) {
		this.date_d_publication = date_d_publication;
	}
	public String getEntreprise() {
		return Entreprise;
	}
	public void setEntreprise(String entreprise) {
		Entreprise = entreprise;
	}
	public String getLieux() {
		return lieux;
	}
	public void setLieux(String lieux) {
		this.lieux = lieux;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getExigences() {
		return exigences;
	}
	public void setExigences(String exigences) {
		this.exigences = exigences;
	}
	public String getCompetances() {
		return competances;
	}
	public void setCompetances(String competances) {
		this.competances = competances;
	}
	public String getPoste() {
		return poste;
	}
	public void setPoste(String poste) {
		this.poste = poste;
	}
	public int getNbplace() {
		return nbplace;
	}
	public void setNbplace(int nbplace) {
		this.nbplace = nbplace;
	}
	public Set<Postule> getcandidats() {
		return candidats;
	}
	public void setcandidats(Set<Postule> candidats) {
		this.candidats = candidats;
	}
	public OffreDembauche(Date date_d_expiration, Date date_d_publication, String entreprise, String lieux,
			String description, String exigences, String competances, String poste, int nbplace, Set<Postule> candidats ) {
		super();
		this.date_d_expiration = date_d_expiration;
		this.date_d_publication = date_d_publication;
		this.Entreprise = entreprise;
		this.lieux = lieux;
		this.description = description;
		this.exigences = exigences;
		this.competances = competances;
		this.poste = poste;
		this.nbplace = nbplace;
		this.candidats = candidats ;
	}
	public OffreDembauche() {
		super();
	}
	@Override
	public String toString() {
		return "OffreDembauche [Date_d_expiration=" + date_d_expiration + ", date_d_publication="
				+ date_d_publication + ", Entreprise=" + Entreprise + ", lieux=" + lieux + ", description="
				+ description + ", exigences=" + exigences + ", competances=" + competances + ", poste=" + poste
				+ ", nbplace=" + nbplace +"]";
	}
	
	
	
}
