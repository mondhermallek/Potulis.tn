package com.esprit.embauche.postule;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;




public interface PostuleRepository extends JpaRepository<Postule, Integer> {
	

}
