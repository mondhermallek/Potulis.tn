package com.esprit.embauche.postule;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.esprit.embauche.offre.OffreDembauche;
import com.fasterxml.jackson.annotation.JsonIgnore;
//import com.fasterxml.jackson.annotation.JsonBackReference;
//import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Postule implements Serializable {
private static final long serialVersionUID = 6;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String Candidat_name,email,phone;
	@JsonIgnore
	//@JsonBackReference
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "offre_id", nullable = false)
   
    private OffreDembauche offreid;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCandidat_name() {
		return Candidat_name;
	}
	public void setCandidat_name(String candidat_name) {
		Candidat_name = candidat_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public OffreDembauche getOffreid() {
		return offreid;
	}
	public void setOffreid(OffreDembauche offreid) {
		this.offreid = offreid;
	}
	public Postule() {
		super();
	}
	public Postule(String candidat_name, String email, String phone, OffreDembauche offreid) {
		super();
		Candidat_name = candidat_name;
		this.email = email;
		this.phone = phone;
		this.offreid=offreid;
	}
	
	
	@Override
	public String toString() {
		return "Postule [Candidat_name=" + Candidat_name + ", email=" + email + ", phone=" + phone
				+ "]";
	}
	

}
