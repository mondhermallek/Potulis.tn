package com.esprit.embauche;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
